from setuptools import setup, find_packages


setup(
    name='feat_eng',
    version='0.1.6',
    author='lhs',
    description='期货交易数据特征工程工具箱',
    python_requires='>=3.7',
    include_package_data=True,

    # 项目主页
    url='http://mayun.itc.cmbchina.cn/IT06202/agtdTeZhengGongCheng',

    packages=find_packages()
)