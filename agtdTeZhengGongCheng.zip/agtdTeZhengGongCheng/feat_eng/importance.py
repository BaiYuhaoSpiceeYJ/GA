from dataclasses import dataclass, field
from typing import Any, List
# from minepy import MINE  # type: ignore
import pandas as pd
import numpy as np

from . import base


# @dataclass
# class MIC(base.BaseTransformerQP, base.CopyMixin):
#     """最大互信息"""
#     alpha: float = 0.6
#     c: int = 15
#     new_col: str = 'y'
#     feat_cols: List[str] = field(default_factory=list)
    
#     res: List[float] = field(default_factory=list, init=False)
    
#     def fit(self, X, y):
#         mine = MINE(alpha=self.alpha, c=self.c)
#         for i in range(X.shape[1]):
#             mine.compute_score(X[:, i], y)
#             self.res.append(mine.mic())
#         return self
    
#     def get_df(self) -> pd.DataFrame:
#         df_mic = pd.Series(self.res, index=self.feat_cols).to_frame(self.new_col)
#         return df_mic
    
#     @classmethod
#     def plot_bar(cls, x: pd.DataFrame, col: str = 'y', *args, **kwargs):
#         xx = x.sort_values(col, ascending=False) if col else x
#         return xx.plot.bar(*args, **kwargs)
            
#     def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
#         return self.copy_or(X)
    
    

@dataclass
class PermutationImportance(base.BaseTransformerQP, base.CopyMixin):
    """排列组合特征重要性"""
    feature_names: List[str] = field(default_factory=list)
    model: base.BaseEstimator = base.BaseEstimator()
    result: Any = None
    n_repeats: int = 10
    random_state: int = 42
    n_jobs: int = 4
    importances: pd.Series = pd.Series()
    
    
    def fit(self, X, y):
        import time
        from sklearn.inspection import permutation_importance
        
        start_time = time.time()
        self.result = permutation_importance(
            self.model, X, y, 
            n_repeats=self.n_repeats, 
            random_state=self.random_state, 
            n_jobs=self.n_jobs
        )
        elapsed_time = time.time() - start_time
        print(f"Elapsed time to compute the importances: "
              f"{elapsed_time:.3f} seconds")
        self.importances = pd.Series(self.result.importances_mean)
        if self.feature_names is not None:
            self.importances.index = self.feature_names  # type: ignore
        self.importances = self.importances.sort_values(ascending=False)
        return self
        
    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self.copy_or(X)
    
    def plot_bar(self, figsize=(12, 4)):
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=figsize)
        self.importances.plot.bar(yerr=self.result.importances_std, ax=ax)
        ax.set_title("Feature importances using permutation on full model")
        ax.set_ylabel("Mean accuracy decrease")
        fig.tight_layout()
        plt.show()
        
        
@dataclass
class MDI(base.BaseEstimator):
    """平均不纯度下降法
    
    Mean Decrease Impurity
    """
    model: base.BaseEstimator = base.BaseEstimator()
    feature_names: List[str] = field(default_factory=list)
    std: np.ndarray = np.array([])
    importances: pd.Series = pd.Series()
    
    def fit(self, X=None, y=None):
        importances = self.model.feature_importances_  # type: ignore
        self.std = np.std([tree.feature_importances_ for tree in self.model.estimators_], axis=0)
        self.importances = importances = pd.Series(importances)
        if self.feature_names is not None:
            self.importances.index = self.feature_names
        self.importances = self.importances.sort_values(ascending=False)
        return self
        
    def plot_bar(self, figsize=(12, 4)):
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=figsize)
        self.importances.plot.bar(yerr=self.std, ax=ax)
        ax.set_title("Feature importances using MDI")
        ax.set_ylabel("Mean decrease in impurity")
        if self.feature_names is not None:
            plt.axhline(y=1/len(self.feature_names),ls=":",c="red")
        else:
            plt.axhline(y=1/len(self.importances),ls=":",c="red")
        fig.tight_layout()