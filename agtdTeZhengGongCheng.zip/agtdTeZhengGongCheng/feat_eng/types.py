from typing import Any, Sequence, Union, TypeVar
import numpy as np
import pandas as pd


T = TypeVar('T')

ArrayLike = Union[np.ndarray, pd.Series, Sequence[Any]]