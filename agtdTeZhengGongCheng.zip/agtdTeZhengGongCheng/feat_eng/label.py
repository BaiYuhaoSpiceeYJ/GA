"""labeling模块"""
import abc
from typing import Any, Callable, List, Sequence, Tuple, Union, overload
from dataclasses import dataclass
import pandas as pd
import numpy as np
from . import stats
from . import ta
from . import base
from . import utils


# 统计未来特征
FutureStats = stats.FutureStats

# 统计过去特征
PastStats = stats.PastStats


def cross_binary(a: pd.Series, b: pd.Series, labels: Tuple[int, int] = (1, -1)) -> pd.Series:
    """金叉死叉打标签

    列A > 列B -> 金叉
    列A <= 列B -> 死叉
    
    :param a: 列A
    :param b: 列B
    :param label: 标签，第一个表示金叉，第二个表示死叉
    """
    return pd.Series(np.where(a > b, labels[0], labels[1]), index=a.index)



def cross_tripple(a: pd.Series, b: pd.Series, labels: Tuple[int, int, int] = (1, 0, -1)) -> pd.Series:
    """金叉死叉打标签

    列A > 列B -> 金叉
    列A < 列B -> 死叉
    列A == 列B -> 相等
    
    :param a: 列A
    :param b: 列B
    :param label: 标签，第一个表示金叉，第二个表示相等，第三个表示死叉
    """
    res = np.zeros(len(a))
    res[:] = labels[1]
    res[a > b] = labels[0]
    res[a < b] = labels[2]
    return pd.Series(res, index=a.index)





class BaseLabelling(base.NoFitTransformer, base.SupportSelector, abc.ABC):
    """labelling基类"""

    def get_new_cols(self) -> List[str]:
        return [self._config.get_new_col()]

    def config(self, key: str, value: Any):
        setattr(self._config, key, value)
        return self

    class Config:
        prefix: str = 'label'
        name_args: Sequence[str] = []

        def get_new_col(self) -> str:
            return utils.concat_str(self.prefix, *self.name_args)

    _config = Config()


class Cross(BaseLabelling):
    """金叉死叉打标签

    列A > 列B -> 金叉
    列A <= 列B -> 死叉
    
    :param a: 列A
    :param b: 列B
    :param labels: 标签，第一个表示金叉，第二个表示死叉
    """

    def __init__(self, col_a: str, col_b: str, labels: Tuple[int, int] = (1, -1)) -> None:
        self.col_a = col_a
        self.col_b = col_b
        self.labels = labels

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.copy()
        label_col = self._config.get_new_col()
        a = data[self.col_a]
        b = data[self.col_b]
        data[label_col] = cross_binary(a , b, labels=self.labels)
        data.loc[data[[self.col_a, self.col_b]].isna().any(axis=1), label_col] = np.nan  # type: ignore
        return data


def make_macd_cross(trans: ta.MACD, labels: Tuple[int, int] = (1, -1)):
    """macd金叉"""
    cols = trans.get_new_cols()
    trans_label = Cross(cols[0], cols[1], labels=labels).config('name_args', (cols[-1],))
    return trans_label


def make_kdj_cross(trans: ta.KDJ, labels: Tuple[int, int] = (1, -1)):
    """kdj金叉"""
    cols = trans.get_new_cols()
    trans_label = Cross(cols[0], cols[1], labels=labels).config('name_args', ('kdj_cross', str(trans.n)))
    return trans_label


class Segment(BaseLabelling):
    """分段打标签

    左开右闭
    
    :param col: 指定列名
    :param bounds: 分段的临界点，从小到大
    :param labels: 标签，长度比bounds小1
    """

    def __init__(self, col: str, bounds: Sequence[float] = (0, 20, 80, 100), labels: Sequence[int] = (-1, 0, 1)) -> None:
        self.col = col
        self.bounds = bounds
        self.labels = labels

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.copy()
        label_col = self._config.get_new_col()
        labels = pd.cut(data[self.col], bins=self.bounds, labels=self.labels, include_lowest=True)  # type: ignore
        data[label_col] = labels
        return data


def make_cci_segment(trans: Union[ta.CCI_A, ta.CCI_B], bounds: Sequence[float] = (0, 20, 80, float('inf')), labels: Sequence[int] = (-1, 0, 1)):
    """cci分段"""
    cols = trans.get_new_cols()
    trans_label = Segment(cols[0], bounds=bounds, labels=labels).config('name_args', (cols[-1],))
    return trans_label


def make_kdj_segment(trans: ta.KDJ, bounds: Sequence[float] = (0, 20, 80, float('inf')), labels: Sequence[int] = (-1, 0, 1)):
    """kdj分段"""
    cols = trans.get_new_cols()
    trans_label = Segment(cols[1], bounds=bounds, labels=labels).config('name_args', ('kdj_seg', str(trans.n)))
    return trans_label


def make_rsi_segment(trans: ta.KDJ, bounds: Sequence[float] = (0, 10, 90, 100), labels: Sequence[int] = (-1, 0, 1)):
    """rsi分段"""
    col = trans.get_new_cols()[0]
    trans_label = Segment(col=col, bounds=bounds, labels=labels).config('name_args', ('rsi', str(trans.n)))
    return trans_label


class DynamicSegment(BaseLabelling):
    """动态分段打标签

    左开右闭
    
    :param col: 比较列
    :param cols: 指定用于分段的列名序列，从小到大排列
    :param labels: 标签，长度比bounds大1
    """

    def __init__(self, col: str = 'last_price',  bounds: Sequence[str] = (), labels: Sequence[int] = (0, 1, 2, 4)) -> None:
        self.col = col
        self.bounds = bounds
        self.labels = labels

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.copy()
        label_col = self._config.get_new_col()
        labels = np.empty(len(X))
        labels[:] = self.labels[-1]
        for i, l in zip(self.bounds[::-1], self.labels[:-1:-1]):
            labels[data[self.col] <= data[i]] = l
        data[label_col] = labels
        data.loc[data[self.bounds].isna().any(axis=1), label_col] = np.nan  # type: ignore
        return data


def make_bolling_segment(trans: ta.Bollin, col: str = 'last_price', labels: Sequence[int] = (0, 1, 2, 3)):
    """布林带分段"""
    cols = trans.get_new_cols()
    trans_label = DynamicSegment(col=col, bounds=cols[::-1], labels=labels).config('name_args', ('bollin', str(trans.n), str(trans.m)))
    return trans_label


# migrate from quant_pipeline


@dataclass
class TripleGrid(base.BaseTransformerQP, base.CopyMixin):
    """栅格法（三分类）"""
    n: int = 5
    upper: float = 0.005
    lower: float = -0.005
    new_col: str = 'y'
    col: str = 'close'
    labels: Tuple[int, int, int] = (1, 0, -1)  # 涨/平/跌

    @classmethod
    def get_triple_grid(cls,
                        x: pd.Series,
                        upper: float,
                        lower: float,
                        labels: Tuple[int, int, int] = (1, 0, -1)):
        up, end, low = labels
        base_ = x.iloc[0]
        for i in x:
            if i/base_ - 1 <= lower:
                return low
            if i/base_ - 1 >= upper:
                return up
        return end

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.copy_or(X)
        data[self.new_col] = data[self.col].rolling(self.n + 1).agg(
            lambda x: self.get_triple_grid(x, self.upper, self.lower, labels=self.labels)
        ).shift(-self.n)
        return data


@dataclass
class QuadraGrid(base.BaseTransformerQP, base.CopyMixin):
    """栅格法（四分类）"""
    n: int = 5
    upper: float = 0.005
    lower: float = -0.005
    new_col: str = 'y'
    col: str = 'close'
    labels: Tuple[int, int, int, int] = (2, 1, -1, -2)  # 涨/微涨/微跌/跌

    @classmethod
    def get_quadra_grid(cls,
                        x: pd.Series,
                        upper: float,
                        lower: float,
                        labels: Tuple[int, int, int, int] = (2, 1, -1, -2)):
        up, uu, ll, low = labels
        base_ = x.iloc[0]
        for i in x:
            if i/base_ - 1 <= lower:
                return low
            if i/base_ - 1 >= upper:
                return up
        return uu if x.iloc[-1]/base_ - 1 > 0 else ll

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.copy_or(X)
        data[self.new_col] = data[self.col].rolling(self.n + 1).agg(
            lambda x: self.get_quadra_grid(x, self.upper, self.lower, labels=self.labels)
        ).shift(-self.n)
        return data


@dataclass
class DynTripleGrid(base.BaseTransformerQP, base.CopyMixin):
    """动态栅格法（三分类）"""
    n: int = 5
    span: int = 20
    alpha_u: float = 1.
    alpha_d: float = 1.
    new_col: str = 'y'
    col: str = 'close'
    labels: Tuple[int, int, int] = (1, 0, -1)  # 涨/平/跌

    @classmethod
    def get_triple_grid(cls,
                        x: pd.Series,
                        y: pd.Series,
                        alpha_u: float,
                        alpha_d: float,
                        labels: Tuple[int, int, int] = (1, 0, -1)):
        up, end, low = labels
        base_ = x.iloc[0]
        std = y.loc[x.index].iloc[0]
        for i in x.iloc[1:]:
            lower = - alpha_d * std
            upper = alpha_u * std
            if i/base_ - 1 <= lower:
                return low
            if i/base_ - 1 >= upper:
                return up
        return end

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.copy_or(X)
        ret = data[self.col].pct_change()
        stds = ret.ewm(span=self.span).std()
        data[self.new_col] = data[self.col].rolling(self.n + 1).agg(
            lambda x: self.get_triple_grid(x, stds, self.alpha_u, self.alpha_d, labels=self.labels)
        ).shift(-self.n)
        return data
