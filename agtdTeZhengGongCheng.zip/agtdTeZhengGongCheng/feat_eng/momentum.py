"""动量特征"""

from pathlib import Path
import sys 
sys.path.append(str(Path(__file__).parent.absolute()))  # 因为py3.7无法在统计目录找到dll文件

import abc
from functools import partial
from typing import Callable
import pandas as pd
import numpy as np
from . import types as tp
from . import data_utils
from . import base
from . import utils
import feat_utils  # type: ignore

class BaseOneColTransformer(base.NoFitTransformer, base.SupportSelector, abc.ABC):
    """过去n个数据点的累计收益率
    
    :param col: 指定列
    :param n: 数据点个数
    :param lag: 滞后项，lag=1时，表示不包含当前时刻
    """

    _prefix: str = ''

    def __init__(self, col: str = 'close', n: int = 1, lag: int = 0) -> None:
        self.col = col
        self.n = n
        self.lag = lag

    @property
    def new_col(self):
        return utils.concat_str(self._prefix, self.col, str(self.n), str(self.lag))
    
    def get_new_cols(self):
        return [self.new_cols]

    def transform(self, X: pd.DataFrame, **kwargs) -> pd.DataFrame:
        data = X.copy()
        res = self.func(X[self.col], n=self.n, lag=self.lag, **kwargs) 
        data[self.new_col] = res.values
        return data

    @abc.abstractmethod
    def func(self, s: pd.Series, n: int, lag: int, *args, **kwargs) -> pd.Series:
        raise NotImplementedError


def accumulated_returns(s: tp.ArrayLike, n: int = 1, lag: int = 0) -> pd.Series:
    """过去n个数据点的累计收益率
    
    :param s: 序列
    :param n: 数据点个数
    :param lag: 滞后项，lag=1时，表示不包含当前时刻
    """
    ss = pd.Series(s)
    res = ss / ss.shift(n) - 1
    return res.shift(lag) if lag > 0 else res


class AccumulatedReturns(BaseOneColTransformer):
    """过去n个数据点的累计收益率
    
    :param col: 指定列
    :param n: 数据点个数
    :param lag: 滞后项，lag=1时，表示不包含当前时刻
    """
    _prefix = 'acc_ret'

    def func(self, s: pd.Series, n: int, lag: int, *args, **kwargs) -> pd.Series:
        return accumulated_returns(s, n=n, lag=lag, *args, **kwargs)

    

def make_new_high(s: tp.ArrayLike, n: int = 52, lag: int = 0) -> pd.Series:
    """是否在过去n个数据点内创新高
    
    :param s: 序列
    :param n: 数据点个数
    :param lag: 滞后项，lag=1时，表示不包含当前时刻
    """
    ss = pd.Series(s)
    res = ss.rolling(n, min_periods=1).max()
    res = res.shift(lag) if lag > 0 else res
    return ss > res


class NewHigh(BaseOneColTransformer):
    """是否在过去n个数据点内创新高
    
    :param col: 指定列
    :param n: 数据点个数
    :param lag: 滞后项，lag=1时，表示不包含当前时刻
    """

    _prefix = 'new_high'

    def func(self, s: pd.Series, n: int, lag: int, *args, **kwargs) -> pd.Series:
        return make_new_high(s, n, lag, *args, **kwargs)


def infomation_diversity(price: tp.ArrayLike, n: int = 52, lag: int = 0, criteria: float = 0.) -> pd.Series:
    """是否在过去n个数据点内信息分散系数
    
    :param price: 价格序列
    :param n: 数据点个数
    :param lag: 滞后项，lag=1时，表示不包含当前时刻
    """
    p = pd.Series(price)
    diff = p.diff()
    # roll = diff.rolling(n)
    # inc = roll.agg(lambda x: (x > criteria).sum())
    # dec = roll.agg(lambda x: (x < -criteria).sum())
    # res = (inc - dec) / n
    # print(diff[-50:])
    res = feat_utils.calc_info_dvrst(diff, n, criteria)
    # res = np.array(res)
    # print(res[-50:])
    res = pd.Series(res)
    return res.shift(lag) if lag > 0 else res


class InfomationDiversity(BaseOneColTransformer):
    """是否在过去n个数据点内信息分散系数
    
    :param col: 指定列
    :param n: 数据点个数
    :param lag: 滞后项，lag=1时，表示不包含当前时刻
    """
    _prefix = 'info_dvrs'

    def __init__(self, col: str, n: int = 52, lag: int = 0, criteria: float = 0.) -> None:
        super().__init__(col=col, n=n, lag=lag)
        self.criteria = criteria
        
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        return super().transform(X, criteria=self.criteria)

    def func(self, s: pd.Series, n: int, lag: int, *args, **kwargs) -> pd.Series:
        return infomation_diversity(s, n, lag, *args, **kwargs)