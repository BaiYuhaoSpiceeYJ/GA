"""生成tick特征"""
from typing import Optional, Sequence, Union

from typing_extensions import Literal
import pandas as pd  # type: ignore
import numpy as np

from . import base
from . import utils


# 计算每个tick的成交量，成交量= [T时刻的撮合交易量 - (T-1)时刻的撮合交易量]/2
def cal_qty(d: pd.DataFrame):
    """计算每个tick的成交量

    成交量= [T时刻的撮合交易量 - (T-1)时刻的撮合交易量]/2
    """
    data=d.copy()
    data.sort_index(level=0,inplace=True)
    #后一个tick减去前一个tick的撮合量，再除以2得到成交量
    data['qty'] = data['matchtot_qty'].diff(1) / 2
    #删除成交量为负值的异常数据
    data=data[data['qty'] >=0]
    #删除撮合量列
    data.drop(columns=['matchtot_qty'], inplace=True)
    data['qty']=data['qty'].astype('int64')
    return data

class CalQty(base.OrderingTransformer):
    """生成tick的成交量

    成交量= [T时刻的撮合交易量 - (T-1)时刻的撮合交易量]/2

    :param qty_col: 累计成交量列名
    :param new_col: 生成列的列名
    :param drop_old: 是否丢弃旧列
    :param drop_abnormal: 是否丢弃异常值所在行
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    qty: Optional[pd.Series] = None

    def __init__(self,
                 qty_col: str = 'matchtot_qty',
                 new_col: str = 'qty',
                 drop_old: bool = True,
                 drop_abnormal: bool = True,
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.qty_col = qty_col
        self.new_col = new_col
        self.drop_old = drop_old
        self.drop_abnormal = drop_abnormal
        self.ordering = ordering
        self._data = None

    def _cust_fit(self, X: pd.DataFrame, y=None):
        self._data = X.copy()
        # 后一个tick减去前一个tick的撮合量，再除以2得到成交量
        self._data[self.new_col] = self._data[self.qty_col].diff(1) / 2
        # 删除成交量为负值的异常数据
        if self.drop_abnormal:
            self._data = self._data.query(f'{self.new_col} >= 0')
        # 删除撮合量列
        if self.drop_old:
            self._data = self._data.drop(columns=[self.qty_col])
        self._data[self.new_col] = self._data[self.new_col].astype('int')
        self.qty = self._data[self.new_col].copy()
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data.copy()


# 计算每个tick的中间价，中间价 =（买一价+卖一价）/2
def cal_mid_price(data):
    data['mid_price'] = (data['best_bid_price_1'] + data['best_ask_price_1']) / 2
    return data


class MidPrice(base.TimeCheckTransformer):
    """生成中间价特征

    中间价 =（买一价+卖一价）/2

    :param col: 生成列的列名
    :param bid_col: 买一价列名
    :param ask_col: 买一价列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """
    mid_price: Optional[pd.Series] = None

    def __init__(self,
                 col: str = 'mid_price',
                 bid_col: str = 'best_bid_price_1',
                 ask_col: str = 'best_ask_price_1',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.col = col
        self.bid_col = bid_col
        self.ask_col = ask_col
        self.ordering = ordering

    def _cust_fit(self, X: pd.DataFrame, y=None):
        X = X.copy()
        self.mid_price = (X[self.bid_col] + X[self.ask_col]) / 2
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.col] = self.mid_price
        return data


# 计算每个tick中间价n元内的买单总量
def cal_bidqty_around_mid_price(data, lb, ub):
    d = data.copy()
    d['lb'] = d['mid_price'] + lb
    d['ub'] = d['mid_price'] + ub
    d.loc[(d['best_bid_price_1'] < d['lb'])|(d['best_bid_price_1'] > d['ub']) , 'best_bid_size_1'] = 0
    d.loc[(d['best_bid_price_2'] < d['lb'])|(d['best_bid_price_2'] > d['ub']), 'best_bid_size_2'] = 0
    d.loc[(d['best_bid_price_3'] < d['lb'])|(d['best_bid_price_3'] > d['ub']), 'best_bid_size_3'] = 0
    d.loc[(d['best_bid_price_4'] < d['lb'])|(d['best_bid_price_4'] > d['ub']), 'best_bid_size_4'] = 0
    d.loc[(d['best_bid_price_5'] < d['lb'])|(d['best_bid_price_5'] > d['ub']), 'best_bid_size_5'] = 0
    d[str(lb)+'_bid_qty'] = d['best_bid_size_1'] + d['best_bid_size_2'] + d['best_bid_size_3'] + d['best_bid_size_4'] + d[
        'best_bid_size_5']
    data[str(lb)+'_bid_qty'] = d[str(lb)+'_bid_qty']
    return data


# 计算每个tick中间价n元内的卖单总量
def cal_askqty_around_mid_price(data, lb,ub):
    d = data.copy()
    d.dropna()

    d['lb'] = d['mid_price'] + lb
    d['ub'] = d['mid_price'] + ub
    d.loc[(d['best_ask_price_1'] < d['lb'])|(d['best_ask_price_1'] > d['ub']), 'best_ask_size_1'] = 0
    d.loc[(d['best_ask_price_2'] < d['lb'])|(d['best_ask_price_2'] > d['ub']), 'best_ask_size_2'] = 0
    d.loc[(d['best_ask_price_3'] < d['lb'])|(d['best_ask_price_3'] > d['ub']), 'best_ask_size_3'] = 0
    d.loc[(d['best_ask_price_4'] < d['lb'])|(d['best_ask_price_4'] > d['ub']), 'best_ask_size_4'] = 0
    d.loc[(d['best_ask_price_5'] < d['lb'])|(d['best_ask_price_5'] > d['ub']), 'best_ask_size_5'] = 0
    d[str(lb)+'_ask_qty'] = d['best_ask_size_1'] + d['best_ask_size_2'] + d['best_ask_size_3'] + d['best_ask_size_4'] + d[
        'best_ask_size_5']
    data[str(lb)+'_ask_qty'] = d[str(lb)+'_ask_qty']
    return data


class QtyAroundMidPrice(base.OrderingTransformer):
    """计算每个tick中间价n元内的买单或卖单总量

    :param typ: 买卖类型，一般是ask or bid
    :param lower: 下界
    :param upper: 上界
    :param lower_col: 生成的下界的列名
    :param upper_col: 生成的上界的列名
    :param mid_col: 中间价的列名
    :param price_fmt: 委托价格列名模板
    :param size_fmt: 委托数量列名模板
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    qty_around: Optional[pd.Series] = None
    new_col: str = ''

    def __init__(self,
                 typ: str = 'ask',
                 lower: float = 0., upper: float = 0.,
                 lower_col: str = 'lb', upper_col: str = 'up',
                 mid_col: str = 'mid_price',
                 price_fmt: str = 'best_{typ}_price_{i}',
                 size_fmt: str = 'best_{typ}_size_{i}',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.typ = typ.lower()
        self.lower = lower
        self.upper = upper
        self.lower_col = lower_col
        self.upper_col = upper_col
        self.mid_col = mid_col
        self._price_fmt = lambda i: price_fmt.format(typ=self.typ, i=i)
        self._size_fmt = lambda i: size_fmt.format(typ=self.typ, i=i)
        self.ordering = ordering
        self.new_col = utils.concat_str(str(self.lower), str(self.upper), self.typ, 'qty')

    def _cust_fit(self, X: pd.DataFrame, y=None):
        self._data = X.copy()
        d = X.copy()
        try:
            mid_price = d[self.mid_col]
        except KeyError:
            mid_price = MidPrice().fit(d).mid_price
        d[self.lower_col] = mid_price + self.lower
        d[self.upper_col] = mid_price + self.upper
        d[self.new_col] = 0
        for i in range(1, 6):
            price_name = self._price_fmt(i)
            bid_col = X[price_name]
            size_name = self._size_fmt(i)
            d.loc[(bid_col < d[self.lower_col]) | (bid_col > d[self.upper_col]), size_name] = 0  # type: ignore
            d[self.new_col] += d[size_name]
        self._data[self.new_col] = d[self.new_col]
        self.qty_around = d[self.new_col].copy()
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data  # type: ignore


#后一个时刻的成交价减去上一个时刻的中间价，正则为流入，负则为流出，数值取成交量
def cal_cash_flow(data):
    d=data[['qty','mid_price','last_price']]
    d['last_tick_mid_price']=d['mid_price'].shift(1)
    d['cash_flow_dir']=d['last_price']-d['last_tick_mid_price']
    d.loc[d['cash_flow_dir']<0,'qty']=(-1)*d.loc[d['cash_flow_dir']<0,'qty']
    data['cash_flow_qty']=d['qty']
    return data


class CashFlow(base.OrderingTransformer):
    """生成现金流

    后一个时刻的成交价减去上一个时刻的中间价，正则为流入，负则为流出，数值取成交量

    :param cash_col: 生成列的列名
    :param qty_col: 成交量列名
    :param mid_col: 中间价的列名
    :param last_col: 成交价的列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    cash_flow: Optional[pd.Series] = None

    def __init__(self,
                 cash_col: str = 'cash_flow_qty',
                 qty_col: str = 'qty',
                 mid_col: str = 'mid_price',
                 last_col: str = 'last_price',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.cash_col = cash_col
        self.qty_col = qty_col
        self.mid_col = mid_col
        self.last_col = last_col
        self.ordering = ordering

    def _cust_fit(self, X: pd.DataFrame, y=None):
        data = X.copy()
        d = data.copy()
        try:
            mid_price = d[self.mid_col]
        except KeyError:
            mid_price = MidPrice().fit(d).mid_price
        try:
            d[self.qty_col]
        except KeyError:
            d[self.qty_col] = CalQty().fit(d).qty
        d['last_tick_mid_price'] = mid_price.shift(1)
        d['cash_flow_dir'] = d[self.last_col] - d['last_tick_mid_price']
        d.loc[d['cash_flow_dir'] < 0, self.qty_col] *= (-1)
        data[self.cash_col] = d[self.qty_col]
        self._data = data
        self.cash_flow = data[self.cash_col]
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data


# 计算买（卖）最大成交量分别占总成交量的比例
# periods：时间窗，单位是秒
# cash_flow_direction：资金流动方向
def cal_max_qty_ratio(data, periods, cash_flow_direction):
    """计算买（卖）最大成交量分别占总成交量的比例

     Example
    ------------
    >>> data=cal_max_qty_ratio(data,'30s','in')
    >>> data=cal_max_qty_ratio(data,'30s','out')
    >>> data=cal_max_qty_ratio(data,'90s','in')
    >>> data=cal_max_qty_ratio(data,'90s','out')
    >>> data=cal_max_qty_ratio(data,'150s','in')
    >>> data=cal_max_qty_ratio(data,'150s','out')
    >>> data.head(5)

    """
    data['sum_qty'] = data['qty'].rolling(window=periods, min_periods=int(periods[:-1])).sum()
    data['temp'] = data['cash_flow_qty']

    if cash_flow_direction == 'in':
        data.loc[data['temp'] < 0, 'temp'] = 0
        data['max_qty_ratio_' + cash_flow_direction + str(periods)] = data['temp'].rolling(window=periods).max() / data[
            'sum_qty']

    if cash_flow_direction == 'out':
        data.loc[data['temp'] > 0, 'temp'] = 0
        data['max_qty_ratio_' + cash_flow_direction + str(periods)] = np.abs(
            data['temp'].rolling(window=periods).min() / data['sum_qty'])

    data.drop(columns=['temp', 'sum_qty'], inplace=True)

    return data


class MaxQtyRatio(base.OrderingTransformer):
    """生成买（卖）最大成交量分别占总成交量的比例

    后一个时刻的成交价减去上一个时刻的中间价，正则为流入，负则为流出，数值取成交量

    :param periods: 时间段序列
    :param min_periods: 最小期数，用于限制rolling过程中至少需要的数据量
    :param cash_flow_direction: 现金流方向
    :param qty_col: 成交量列名
    :param cash_col: 生成列列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    max_qty_ratio: Optional[pd.Series] = None

    def __init__(self,
                 periods: Union[str, int] = '60S',
                 min_periods: int = 1,
                 cash_flow_direction: Literal['in', 'out'] = 'in',
                 cash_col: str = 'cash_flow_qty',
                 qty_col: str = 'qty',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.periods = periods
        self.min_periods = min_periods
        self.cash_flow_direction = cash_flow_direction
        self.qty_col = qty_col
        self.cash_col = cash_col
        self.ordering = ordering

    def _cust_fit(self, X: pd.DataFrame, y=None):
        data = X.copy()
        try:
            quantity = data[self.qty_col]
        except KeyError:
            quantity = CalQty().fit(data).qty
        data['sum_qty'] = quantity.rolling(window=self.periods, min_periods=self.min_periods).sum()
        try:
            cash_flow = data[self.cash_col]
        except KeyError:
            cash_flow = CashFlow().fit(data).cash_flow
        data['temp'] = cash_flow

        ratio_col = utils.concat_str('max_qty_ratio', self.cash_flow_direction, str(self.periods))
        if self.cash_flow_direction == 'in':
            data.loc[data['temp'] < 0, 'temp'] = 0

            data[ratio_col] = data['temp'].rolling(window=self.periods).max() / data['sum_qty']

        if self.cash_flow_direction == 'out':
            data.loc[data['temp'] > 0, 'temp'] = 0
            data[ratio_col] = np.abs(data['temp'].rolling(window=self.periods).min() / data['sum_qty'])

        data.drop(columns=['temp', 'sum_qty'], inplace=True)
        self._data = data
        self.max_qty_ratio = data[ratio_col]
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data


def pending_ask_cash_flow(data, lb, ub, periods):
    # 计算每行中间价边界内的挂单量，将结果向后平移一行，相当于将T-1时刻的挂单量平移到T时刻所在的行。
    d = data.copy()
    d = cal_askqty_around_mid_price(d, lb, ub)
    data['t-1'] = d[str(lb) + '_ask_qty'].shift(1)
    d.drop(columns=[str(lb) + '_ask_qty'], inplace=True)

    # 将T-1时刻的中间价边界向下平移一行，使得T时刻可以按照T-1时刻的边界来计算挂单量。
    # 首先向下平移一行中间价
    d['mid_price'] = d['mid_price'].shift(1)
    # 根据T-1时刻的中间价，再次计算一个边界内挂单量，该值就是T时刻按照T-1时刻的边界计算的挂单量
    d = cal_askqty_around_mid_price(d, lb, ub)
    data['t'] = d[str(lb) + '_ask_qty']
    d = []
    # 计算T时刻与T-1时刻的挂单量差，并用成交量修正
    # 卖挂单量，受到资金流入的成交量影响
    data['qty_modify'] = data['cash_flow_qty']
    data.loc[data['qty_modify'] < 0, 'qty_modify'] = 0
    data['pending_ask_' + str(lb) + '_' + str(ub) + '_cash_flow'] = data['t'] - data['t-1'] + data['qty_modify']
    data.drop(columns=['t-1', 't', 'qty_modify'], inplace=True)

    for period in periods:
        data['pending_ask_' + str(lb) + '_' + str(ub) + '_cash_flow_' + period] = data[
            'pending_ask_' + str(lb) + '_' + str(ub) + '_cash_flow'].rolling(window=period,
                                                                             min_periods=int(period[:-1])).sum()

    return data


def pending_bid_cash_flow(data, lb, ub, periods):
    # 计算每行中间价边界内的挂单量，将结果向后平移一行，相当于将T-1时刻的挂单量平移到T时刻所在的行。
    d = data.copy()
    d = cal_bidqty_around_mid_price(d, lb, ub)
    data['t-1'] = d[str(lb) + '_bid_qty'].shift(1)
    d.drop(columns=[str(lb) + '_bid_qty'], inplace=True)

    # 将T-1时刻的中间价边界向下平移一行，使得T时刻可以按照T-1时刻的边界来计算挂单量。
    # 首先向下平移一行中间价
    d['mid_price'] = d['mid_price'].shift(1)
    # 根据T-1时刻的中间价，再次计算一个边界内挂单量，该值就是T时刻按照T-1时刻的边界计算的挂单量
    d = cal_bidqty_around_mid_price(d, lb, ub)
    data['t'] = d[str(lb) + '_bid_qty']
    d = []
    # 计算T时刻与T-1时刻的挂单量差，并用成交量修正
    # 买挂单量，受到资金流出的成交量影响
    data['qty_modify'] = data['cash_flow_qty'] * (-1)
    data.loc[data['qty_modify'] < 0, 'qty_modify'] = 0
    data['pending_bid_' + str(lb) + '_' + str(ub) + '_cash_flow'] = data['t'] - data['t-1'] + data['qty_modify']
    data.drop(columns=['t-1', 't', 'qty_modify'], inplace=True)

    for period in periods:
        data['pending_bid_' + str(lb) + '_' + str(ub) + '_cash_flow_' + period] = data[
            'pending_bid_' + str(lb) + '_' + str(ub) + '_cash_flow'].rolling(window=period,
                                                                             min_periods=int(period[:-1])).sum()

    return data


class PendingOrderCashFlow(base.OrderingTransformer):
    """生成委托买（卖）现金流

    :param typ: 买卖类型，一般ask or bid
    :param lower: 下届
    :param upper: 上界
    :param periods: 时间段序列
    :param min_periods: 最小期数，用于限制rolling过程中至少需要的数据量，与`periods`长度一致, 默认是与periods长度一样的[1, 1, ...]序列
    :param mid_col: 中间价列名
    :param cf_qty_col: 成交量现金流列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    def __init__(self,
                 typ: str,
                 lower: float = 1.,
                 upper: float = 1.,
                 periods: Sequence[str] = ('30s','90s','150s'),
                 min_periods: Sequence[int] = (),
                 mid_col: str = 'mid_price',
                 cf_qty_col: str = 'cash_flow_qty',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.typ = typ
        self.lower = lower
        self.upper = upper
        self.periods = periods
        self.min_periods = min_periods or [1] * len(periods)
        self.ordering = ordering
        self.mid_col = mid_col
        self.cf_qty_col = cf_qty_col

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        d = data.copy()
        _qty_around_mid_price = QtyAroundMidPrice(self.typ, lower=self.lower, upper=self.upper).fit(d)
        d = _qty_around_mid_price.transform(d)
        # data['t-1'] = d[str(self.lower) + f'_{self.typ}_qty'].shift(1)
        data['t-1'] = _qty_around_mid_price.qty_around.shift(1)
        d.drop(columns=[_qty_around_mid_price.new_col], inplace=True)

        # 将T-1时刻的中间价边界向下平移一行，使得T时刻可以按照T-1时刻的边界来计算挂单量。
        # 首先向下平移一行中间价
        try: 
            d[self.mid_col]
        except KeyError:
            d[self.mid_col] = MidPrice().fit(d).mid_price
        d[self.mid_col] = d[self.mid_col].shift(1)
        # 根据T-1时刻的中间价，再次计算一个边界内挂单量，该值就是T时刻按照T-1时刻的边界计算的挂单量
        d = _qty_around_mid_price.fit(d).transform(d)
        data['t'] = d[_qty_around_mid_price.new_col]
        # d = []
        # 计算T时刻与T-1时刻的挂单量差，并用成交量修正
        # 卖挂单量，受到资金流入的成交量影响
        try:
            cf_qty = data[self.cf_qty_col]
        except KeyError:
            cf_qty = CashFlow().fit(d).cash_flow
        data['qty_modify'] = cf_qty
        data.loc[data['qty_modify'] < 0, 'qty_modify'] = 0
        new_col = utils.concat_str('pending', self.typ, str(self.lower), str(self.upper), 'cash_flow')
        data[new_col] = data['t'] - data['t-1'] + data['qty_modify']
        data.drop(columns=['t-1', 't', 'qty_modify'], inplace=True)

        for period, min_p in zip(self.periods, self.min_periods):
            data[new_col + '_' + str(period)] = data[new_col].rolling(window=period, min_periods=min_p).sum()

        return data


# 计算每个tick价差，卖一价 - 买一价
def cal_spread(data):
    d = data.copy()
    d['bid_ask_spread'] = (d['best_ask_price_1'] - d['best_bid_price_1']) / 2
    return d


class Spread(base.TimeCheckTransformer):
    """生成价差

    :param col: 生成列列名
    :param ask_col: 下届
    :param bid_col: 上界
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """
    spread: Optional[pd.Series] = None

    def __init__(self,
                 col: str = 'bid_ask_spread',
                 ask_col: str = 'best_ask_price_1',
                 bid_col: str = 'best_bid_price_1',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.col = col
        self.ask_col = ask_col
        self.bid_col = bid_col
        self.ordering = ordering


    def _cust_fit(self, X: pd.DataFrame, y=None):
        self.spread = (X[self.ask_col] - X[self.bid_col]) / 2
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.col] = self.spread.copy()
        return data


# 相对价差，价差 / 中间价
def cal_spreads_rel(self, data):
    """相对价差"""
    d = data.copy()
    d['spreads_rel'] = (d['best_ask_price_1'] - d['best_bid_price_1']) / (
            (data['best_bid_price_1'] + data['best_ask_price_1']) / 2)
    return d


class RelativeSpread(base.TimeCheckTransformer):
    """生成相对价差

    价差 / 中间价

    :param col: 生成列列名
    :param ask_col: 卖一价列名
    :param bid_col: 买一价列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    relative_spread: Optional[pd.Series] = None

    def __init__(self,
                 col: str = 'spreads_rel',
                 ask_col: str = 'best_ask_price_1',
                 bid_col: str = 'best_bid_price_1',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.col = col
        self.ask_col = ask_col
        self.bid_col = bid_col
        self.ordering = ordering

    def _cust_fit(self, X: pd.DataFrame, y=None):
        spread = Spread(ask_col=self.ask_col, bid_col=self.bid_col).fit(X).spread
        mid_price = MidPrice(ask_col=self.ask_col, bid_col=self.bid_col).fit(X).mid_price
        self.relative_spread = spread / mid_price

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.col] = self.relative_spread
        return data


# 计算深度， 深度=买一价t*买一量t - 卖一价t*卖一量t
def cal_depth(data: pd.DataFrame):
    """计算深度"""
    return data.assign(
        depth=lambda x: x.best_bid_price_1 * x.best_bid_size_1 - x.best_ask_price_1 * x.best_ask_size_1
    )

class Depth(base.TimeCheckTransformer):
    """生成深度

    :param col: 生成列列名
    :param ask_col: 卖一价列名
    :param bid_col: 买一价列名
    :param ask_size: 卖一量列名
    :param bid_size: 买一量列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    depth: Optional[pd.Series] = None

    def __init__(self,
                 col: str = 'depth',
                 ask_col: str = 'best_ask_price_1',
                 bid_col: str = 'best_bid_price_1',
                 ask_size: str = 'best_ask_size_1',
                 bid_size: str = 'best_bid_size_1',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.col = col
        self.ask_col = ask_col
        self.bid_col = bid_col
        self.ask_size = ask_size
        self.bid_size = bid_size
        self.ordering = ordering

    def _cust_fit(self, X: pd.DataFrame, y=None):
        X = X.copy()
        X[self.col] = X[self.bid_col] * X[self.bid_size] - X[self.ask_col] * X[self.ask_size]
        self.depth = X[self.col]
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.col] = self.depth
        return data


# 量差，买一卖一量差，买一量t - 卖一量t
def cal_vol_diff_1(self, data: pd.DataFrame):
    """买一卖一量差"""
    return data.assign(
        vol_diff_1=lambda x: x.best_bid_size_1 - x.best_ask_size_1
    )


class VolDiff(base.TimeCheckTransformer):
    """生成指定档位委托买卖量差

    :param n: 档位
    :param col: 生成列列名
    :param ask_size: 卖一量列名
    :param bid_size: 买一量列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """
    vol_diff: Optional[pd.Series] = None

    def __init__(self,
                 n: int = 1,
                 col: str = 'vol_diff',
                 ask_size: str = 'best_bid_size_{n}',
                 bid_size: str = 'best_ask_size_{n}',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.n = n
        self.col = col
        self.ask_size = ask_size
        self.bid_size = bid_size
        self.ordering = ordering


    def _cust_fit(self, X: pd.DataFrame, y=None):
        self.vol_diff = X[self.bid_size.format(n=self.n)] - X[self.ask_size.format(n=self.n)]
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        col_name = f'{self.col}_{self.n}'
        data[col_name] = self.vol_diff.copy()
        return data

# 买卖总量差，买一到买五的量 - 卖一到卖五的量
def cal_vol_diff_tot(data: pd.DataFrame):
    """买卖总量差"""
    return data.assign(
        vol_diff_tot=lambda x: x.loc[:, x.columns.str.contains("bid_size")].sum(axis=1)
                               - x.loc[:, x.columns.str.contains("ask_size")].sum(axis=1)
    )

class VolDiffTot(base.TimeCheckTransformer):
    """生成全体档位委托买卖量差

    :param col: 生成列列名
    :param ask_size: 卖一量列名关键字
    :param bid_size: 买一量列名关键字
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """
    vol_diff_tot: Optional[pd.Series] = None

    def __init__(self,
                 col: str = 'vol_diff_tot',
                 ask_size: str = 'ask_size',
                 bid_size: str = 'bid_size',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.col = col
        self.ask_size = ask_size
        self.bid_size = bid_size
        self.ordering = ordering


    def _cust_fit(self, X: pd.DataFrame, y=None):
        tot_ask = X.loc[:, X.columns.str.contains("ask_size")].sum(axis=1)
        tot_bid = X.loc[:, X.columns.str.contains("bid_size")].sum(axis=1)
        self.vol_diff_tot = tot_bid - tot_ask
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.col] = self.vol_diff_tot.copy()
        return data

# 斜率，价差t / 深度t
def cal_slope(self, data: pd.DataFrame):
    """计算斜率"""
    return data.assign(
        slope=lambda x: (x['best_ask_price_1'] - x['best_bid_price_1']) / 2
                        / (x.best_bid_price_1 * x.best_bid_size_1 - x.best_ask_price_1 * x.best_ask_size_1)
    )

class Slope(base.TimeCheckTransformer):
    """生成斜率

    :param col: 生成列列名
    :param ask_col: 卖一价列名
    :param bid_col: 买一价列名
    :param ask_size: 卖一量列名
    :param bid_size: 买一量列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """
    slope: Optional[pd.Series] = None

    def __init__(self,
                 col: str = 'slope',
                 ask_col: str = 'best_ask_price_1',
                 bid_col: str = 'best_bid_price_1',
                 ask_size: str = 'best_ask_size_1',
                 bid_size: str = 'best_bid_size_1',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.col = col
        self.ask_col = ask_col
        self.bid_col = bid_col
        self.ask_size = ask_size
        self.bid_size = bid_size
        self.ordering = ordering


    def _cust_fit(self, X: pd.DataFrame, y=None):
        self._data = X.copy()
        self._data[self.col] = ((X[self.ask_col] - X[self.bid_col]) / 2
                                / (X[self.bid_col] * X[self.bid_size] - X[self.ask_col] * X[self.ask_size]))
        self.slope = self._data[self.col]
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data.copy()

# 价差有效性，（成交价t - 中间价t）**2 / 中间价t
def cal_spreads_efficiency(self, data: pd.DataFrame):
    """价差有效性"""
    return data.assign(
        spreads_efficiency=lambda x: (x.last_price - (x['best_ask_price_1'] - x['best_bid_price_1']) / 2) ** 2
                                     / ((x['best_ask_price_1'] - x['best_bid_price_1']) / 2)
    )

class SpreadEfficiency(base.TimeCheckTransformer):
    """生成价差有效性

    （成交价t - 中间价t）**2 / 中间价t

    :param col: 生成列列名
    :param last_price: 成交价列名
    :param bid_col: 买一价列名
    :param ask_col: 卖一价列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """
    spread_efficiency: Optional[pd.Series] = None

    def __init__(self,
                 col: str = 'spreads_efficiency',
                 last_price = 'last_price',
                 ask_col: str = 'best_ask_price_1',
                 bid_col: str = 'best_bid_price_1',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.col = col
        self.last_price = last_price
        self.ask_col = ask_col
        self.bid_col = bid_col
        self.ordering = ordering

    def _cust_fit(self, X: pd.DataFrame, y=None):
        self._data = X.copy()
        mid_price = (self._data[self.ask_col] -  self._data[self.bid_col]) / 2
        self._data[self.col] = (self._data[self.last_price] - mid_price) ** 2 / mid_price
        self.spread_efficiency = self._data[self.col]
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data.copy()

# 资金净流入，（成交价 - 中间价） * 成交量
def cal_net_cash_in(data: pd.DataFrame):
    """资金净流入"""
    return data.assign(
        net_cash_in=lambda x: (x.last_price - (x['best_ask_price_1'] + x['best_bid_price_1']) / 2)
                              * x.qty
    )


class NetCashIn(base.TimeCheckTransformer):
    """资金净流入

    （成交价 - 中间价） * 成交量

    :param col: 生成列列名
    :param qty_col: 成交量列名
    :param last_price: 成交价列名
    :param bid_col: 买一价列名
    :param ask_col: 卖一价列名
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """
    net_cash_in: Optional[pd.Series] = None

    def __init__(self,
                 col: str = 'net_cash_in',
                 mid_col: str = 'mid_price',
                 qty_col: str = 'qty',
                 last_price = 'last_price',
                 ask_col: str = 'best_ask_price_1',
                 bid_col: str = 'best_bid_price_1',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.col = col
        self.mid_col = mid_col
        self.qty_col = qty_col
        self.last_price = last_price
        self.ask_col = ask_col
        self.bid_col = bid_col
        self.ordering = ordering

    def _cust_fit(self, X: pd.DataFrame, y=None):
        self._data = X.copy()
        try:
            mid_price = self._data[self.mid_col]
        except KeyError:
            mid_price = (self._data[self.ask_col] -  self._data[self.bid_col]) / 2
        try:
            qty = self._data[self.qty_col]
        except KeyError:
            qty = CalQty().fit(self._data).qty
        self._data[self.col] = (self._data[self.last_price] - mid_price) * qty
        self.net_cash_in = self._data[self.col]
        return self

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data.copy()