"""bar特征"""
from typing import Optional
from typing_extensions import Literal
from dataclasses import dataclass
import pandas as pd
import numpy as np

from . import base


def get_body_ratio(o: pd.Series, h: pd.Series, l: pd.Series, c: pd.Series):
    """主体占比
    
    开盘收盘价差 / 最高最低价差
    """
    values = np.where(h - l == 0, 0, (o - c).abs() / (h - l))
    return pd.Series(values, index=o.index)


class BodyRatio(base.TimeCheckTransformer, base.SupportSelector):
    """实体所占比例"""
    def __init__(self, new_col: str = 'boday_ratio',  open: str = 'open', high: str = 'high', low: str = 'low', close: str = 'close',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc') -> None:
        self.new_col = new_col
        self.new_cols = [self.new_col]
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.ordering = ordering

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.new_col] = get_body_ratio(data[self.open], data[self.high], data[self.low], data[self.close])
        return data


class BodyLength(base.TimeCheckTransformer, base.SupportSelector):
    """实体长度"""

    def __init__(self, new_col: str = 'boday_length',  open: str = 'open', high: str = 'high', low: str = 'low', close: str = 'close',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc') -> None:
        self.new_col = new_col
        self.new_cols = [self.new_col]
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.ordering = ordering

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.new_col] = np.where(data[self.high] - data[self.low] == 0, 0, (data[self.open] - data[self.close]).abs())
        return data


class LowerShadow(base.TimeCheckTransformer, base.SupportSelector):
    """下影线长度"""

    def __init__(self, new_col: str = 'lower_shadow',  open: str = 'open', high: str = 'high', low: str = 'low', close: str = 'close',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc') -> None:
        self.new_col = new_col
        self.new_cols = [self.new_col]
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.ordering = ordering

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.new_col] = np.where(data[self.open] < data[self.close], data[self.open], data[self.close]) - data[self.low]
        return data



class UpperShadow(base.TimeCheckTransformer, base.SupportSelector):
    """上影线长度"""

    def __init__(self, new_col: str = 'upper_shadow',  open: str = 'open', high: str = 'high', low: str = 'low', close: str = 'close',
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc') -> None:
        self.new_col = new_col
        self.new_cols = [self.new_col]
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.ordering = ordering

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        data[self.new_col] = data[self.high] - np.where(data[self.open] > data[self.close], data[self.open], data[self.close])
        return data



@dataclass
class ShadowLength(base.BarParams, base.BaseTransformerQP, base.CopyMixin):
    """影线长度"""
    new_col: str = 'shadow_length'
    typ: Literal['upper', 'lower'] = 'upper'

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.copy_or(X)
        if self.typ == 'upper':
            a = data[self.col_high]
            b = data[[self.col_open, self.col_close]].max(axis=1)
        elif self.typ == 'lower':
            a = data[self.col_low]
            b = data[[self.col_open, self.col_close]].min(axis=1)
        else:
            raise ValueError('wrong `typ`')
        data[self.new_col] = (a - b).abs()  # type: ignore
        return data


@dataclass
class ShadowRatio(base.BarParams, base.BaseTransformerQP, base.CopyMixin):
    """影线比例"""
    new_col: str = 'shadow_ratio'
    col_shadow_len: str = 'shadow_length'
    typ: Literal['upper', 'lower'] = 'upper'

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.copy_or(X)
        if self.col_shadow_len not in data:
            ncol = f'_shadow_{self.typ}'
            shadow_len = (ShadowLength(new_col=ncol,
                                       typ=self.typ,
                                       col_open=self.col_open,
                                       col_high=self.col_high,
                                       col_low=self.col_low,
                                       col_close=self.col_close)
                          .fit_transform(data)[ncol])
        else:
            shadow_len = data[self.col_shadow_len]
        tot_len = data[self.col_high] - data[self.col_low]
        data[self.new_col] = np.where((shadow_len > 0) & (tot_len > 0),
                                      shadow_len / tot_len, 0)  # 一字板的时候认为比例是0
        return data


@dataclass
class IsGap(base.BarParams, base.BaseTransformerQP, base.CopyMixin):
    """当前值是否是缺口"""
    new_col: str = 'is_gap'

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.copy_or(X)
        is_gap_up = (data[self.col_open] > data[self.col_close].shift(1)) & (data[self.col_close] > data[self.col_open])
        is_gap_down = (data[self.col_open] < data[self.col_close].shift(1)) & (
                data[self.col_close] < data[self.col_open])
        data[self.new_col] = np.where(is_gap_up | is_gap_down, 1, 0)
        return data


@dataclass
class GapMid(base.BarParams, base.BaseTransformerQP, base.CopyMixin):
    """缺口的均值
    
    （当前值 + 前一个值）/2
    """
    new_col: str = 'gap_mid'
    col_is_gap: str = 'is_gap'

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.copy_or(X)
        if self.col_is_gap not in data:
            ncol = f'_is_gap'
            is_gap = (IsGap(new_col=ncol,
                            col_open=self.col_open,
                            col_high=self.col_high,
                            col_low=self.col_low,
                            col_close=self.col_close)
                      .fit_transform(data))[ncol]
        else:
            is_gap = data[self.col_is_gap]
        idx = np.arange(len(data))
        idx_for = idx[is_gap == 1]
        idx_back = idx_for - 1
        idx_back[idx_back < 0] = 0
        data[self.new_col] = (data[self.col_close].iloc[idx_for] + data[self.col_close].iloc[
            idx_back].values) / 2  # type: ignore
        return data
