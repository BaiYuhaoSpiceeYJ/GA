import pandas as pd
from . import types as tp


def coerce_na(target: tp.ArrayLike, ref: tp.ArrayLike) -> pd.Series:
    """将序列1的缺失值用序列2填补
    
    :param target: 序列1
    :param ref: 序列2
    """
    ss1 = pd.Series(target)
    ss2 = pd.Series(ref)
    ss1[ss1.isna()] = ss2[ss1.isna()]
    return ss1