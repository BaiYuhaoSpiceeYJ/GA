"""预处理"""
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import make_pipeline
import pandas as pd  # type: ignore
from pandas.api.types import is_datetime64_dtype
from typing import NamedTuple


class ConvertToTime(BaseEstimator, TransformerMixin):
    """将指定列转为时间格式

    :param time_col: 列名

    >>> trans = ConvertToTime('close')
    >>> data = trans.fit_transform(data)
    """

    def __init__(self, time_col: str):
        self.time_col = time_col

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.copy()
        data[self.time_col] = pd.to_datetime(data[self.time_col])
        return data


class SetTimeIndex(BaseEstimator, TransformerMixin):
    """将指定列转化为时间格式，并设置为index

    :param time_col: 列名
    """

    def __init__(self, time_col: str):
        self.time_col = time_col

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame, ) -> pd.DataFrame:
        data = X.copy()
        _trans = ConvertToTime(self.time_col)
        data = _trans.fit_transform(data)
        data = data.set_index(self.time_col)
        return data


class SortTimeIndex(BaseEstimator, TransformerMixin):
    """按时间索引排序

    :param ascending: True -> 升序; False -> 降序
    """

    def __init__(self, ascending: bool = True):
        self.ascending = ascending

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if not is_datetime64_dtype(X.index):
            raise ValueError('index must be type of time')
        data = X.copy()
        return data.sort_index(ascending=self.ascending)


class TimeRangePicker(BaseEstimator, TransformerMixin):
    """筛选时间段内的数据

    :param start: 开始时间
    :param end: 结束时间
    """

    def __init__(self, start: str, end: str):
        self.start = start
        self.end = end

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if not is_datetime64_dtype(X.index):
            raise ValueError('index must be type of time')
        return X.between_time(self.start, self.end)


class TimeSpan(NamedTuple):
    """时间段类"""
    start: str
    end: str


class TradingTimePicker(BaseEstimator, TransformerMixin):
    """筛选交易时间内的数据

    :param time_spans: 交易时间段序列
    """

    def __init__(self,
                 time_spans=(
                         TimeSpan(start='09:00:00', end='15:30:00'),
                         TimeSpan(start='19:50:00', end='24:00:00'),
                         TimeSpan(start='00:00:00', end='02:30:00'),
                 )):

        self.time_spans = time_spans
        # self._pipe = make_pipeline(
        #     TimeRangePicker(start=start, end=end)
        #     for start, end in self.time_spans
        # )

    def fit(self, X=None, y=None):
        # self._pipe.fit(X, y)
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if not is_datetime64_dtype(X.index):
            raise ValueError('index must be type of time')
        # data = self._pipe.transform(X)
        data = X.copy()
        res = []
        for start, end in self.time_spans:
            d = TimeRangePicker(start=start, end=end).fit_transform(data)
            res.append(d)
        return pd.concat(res, axis=0)


class AgSpotTradingTimePicker(TradingTimePicker):
    """筛选白银现货交易时间内的数据

    :param time_spans: 交易时间段序列
    """

    def __init__(self,
                 time_spans = (
                     TimeSpan(start='09:00:00', end='15:30:00'),
                     TimeSpan(start='19:50:00', end='23:59:59'),
                     TimeSpan(start='00:00:00', end='02:30:00'),
                 )):

        super().__init__(time_spans=time_spans)



class AgFutureTradingTimePicker(TradingTimePicker):
    """筛选白银期货交易时间内的数据

    :param time_spans: 交易时间段序列
    """

    def __init__(self,
                 time_spans=(
                         TimeSpan(start='09:00:00', end='10:15:00'),
                         TimeSpan(start='10:30:00', end='11:30:00'),
                         TimeSpan(start='13:30:00', end='15:00:00'),
                 )):
        super().__init__(time_spans=time_spans)


def common_ag_spot_preprocess(data: pd.DataFrame, time_col: str) -> pd.DataFrame:
    """通用时间处理pipeline"""
    common_pipeline = make_pipeline(
        SetTimeIndex(time_col),
        AgSpotTradingTimePicker(),
        SortTimeIndex(),
    )
    return common_pipeline.fit_transform(data)


def common_ag_future_preprocess(data: pd.DataFrame, time_col: str) -> pd.DataFrame:
    """通用时间处理pipeline"""
    common_pipeline = make_pipeline(
        SetTimeIndex(time_col),
        AgFutureTradingTimePicker(),
        SortTimeIndex(),
    )
    return common_pipeline.fit_transform(data)
