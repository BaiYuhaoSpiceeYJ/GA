"""通用基类和接口"""
import abc
from typing import Optional
from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd
from typing_extensions import Protocol, Literal
from pandas.api.types import is_datetime64_dtype


class SupportTransform(Protocol):

    @abc.abstractmethod
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError


class SupportFit(Protocol):

    @abc.abstractmethod
    def fit(self, X, y):
        raise NotImplementedError


class SupportEmptyFit(SupportFit, Protocol):

    def fit(self, X=None, y=None):
        return self

class SupportTimeIndexCheck(Protocol):

    def check_time_index(self, X: pd.DataFrame):
        self._check_time_index(X)
        return X

    def _check_time_index(self, X: pd.DataFrame):
        if not is_datetime64_dtype(X.index):
            raise ValueError('index must be type of time')


class SupportTimeIndexCheckFit(SupportFit, SupportTimeIndexCheck, Protocol):
    ordering: Optional[Literal['asc', 'dsc']]

    def fit(self, X: pd.DataFrame, y=None):
        self._check_time_index(X)
        data = X.copy()
        if self.ordering == 'asc':
            data = data.sort_index(ascending=True)
        elif self.ordering == 'dsc':
            data = data.sort_index(ascending=False)
        self._cust_fit(data, y)
        return self

    def _cust_fit(self, X: pd.DataFrame, y=None):
        """customize fit fuc"""
        return


class SupportTimeIndexCheckTransform(SupportTransform, SupportTimeIndexCheck, Protocol):

    @abc.abstractmethod
    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        raise NotImplementedError

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.check_time_index(X)
        return self._cust_transform(data, *args, **kwargs)



class SupportSaveDataFit(SupportFit, SupportTimeIndexCheck, Protocol):
    _data: Optional[pd.DataFrame] = None

    def fit(self, X: pd.DataFrame, y=None):

        self._data = self.check_time_index(X).copy()
        self._cust_fit(self._data, y)
        return self

    def _cust_fit(self, X: pd.DataFrame, y=None):
        """customize fit fuc"""
        return


class SupportOrderingFit(SupportFit, Protocol):

    ordering: Optional[Literal['asc', 'dsc']]
    _data: Optional[pd.DataFrame]

    def fit(self, X: pd.DataFrame, y=None):

        if not is_datetime64_dtype(X.index):
            raise ValueError('index must be type of time')
        self._data = X.copy()
        if self.ordering == 'asc':
            self._data = self._data.sort_index(ascending=True)
        elif self.ordering == 'dsc':
            self._data = self._data.sort_index(ascending=False)
#         else:
#             self._data = X

        self._cust_fit(self._data, y)
        return self

    def _cust_fit(self, X: pd.DataFrame, y=None):
        """customize fit fuc"""
        return

    def choose_data(self, X: pd.DataFrame) -> pd.DataFrame:
        if self._data is not None:
            return X.sort_index(ascending=True)
        return self._data.copy()



class BaseTransformer(BaseEstimator, TransformerMixin):
    pass


class NoFitTransformer(BaseTransformer, SupportEmptyFit, SupportTransform):
    pass



class OrderingTransformer(BaseTransformer, SupportOrderingFit, SupportTransform, abc.ABC):

    @abc.abstractmethod
    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        raise NotImplementedError

    def transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = self.choose_data(X)
        return self._cust_transform(data, *args, **kwargs)



class TimeCheckTransformer(BaseTransformer, SupportTimeIndexCheckFit, SupportTimeIndexCheckTransform, abc.ABC):

    pass

