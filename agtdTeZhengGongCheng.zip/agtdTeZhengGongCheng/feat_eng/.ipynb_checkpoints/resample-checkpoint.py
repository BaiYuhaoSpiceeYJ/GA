"""重抽样"""
from typing import Optional, Callable
from typing_extensions import Literal
import pandas as pd

from . import base


class Resampler(base.OrderingTransformer):
    """重抽样

    :param rule: 抽样规则，见pandas resample方法的文档
    :param method: 统计方法，常见的有max min std mean
    :param func: 自定义统计函数
    :param sample_args: pandas resample方法其他参数
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    def __init__(self,
                 rule: str = '1s',
                 method: str = 'last',
                 func: Optional[Callable] = None,
                 sample_args: dict =None,
                 ordering:Optional[Literal['asc', 'dsc']] = 'asc'):
        self.rule = rule
        self.method = method
        self.func = func
        self.resample_ars = sample_args or {}
        self.ordering = ordering


    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return X.resample(self.rule, **self.resample_ars).agg(self.func or self.method)


class TimeSampler(base.OrderingTransformer):
    """按指定时间重抽样

    :param n: 时间数
    :param method: 统计方法，常见的有max min std mean
    :param func: 自定义统计函数
    :param sample_args: pandas resample方法其他参数
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    unit: str = 'S'

    def __init__(self,
                 n: int = 1,
                 method: str = 'last',
                 sample_ars: dict = None,
                 func: Optional[Callable] = None,
                 ordering: Optional[Literal['asc', 'dsc']] = 'asc'):
        self.n = n
        self.method = method
        self.func = func
        self.sample_args = sample_ars
        self.ordering = ordering
        self._data = None

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        rule = str(self.n) + self.unit
        sampler = Resampler(rule=rule,
                            method=self.method,
                            func=self.func,
                            sample_args=self.sample_args,
                            ordering=None).fit(X)
        return sampler.transform(X)


class SecondSampler(TimeSampler):
    """按指定秒数时间重抽样

    :param n: 秒数
    :param method: 统计方法，常见的有max min std mean
    :param func: 自定义统计函数
    :param sample_args: pandas resample方法其他参数
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    unit = 'S'


class MinuteSampler(TimeSampler):
    """按指定分钟数时间重抽样

    :param n: 分钟数
    :param method: 统计方法，常见的有max min std mean
    :param func: 自定义统计函数
    :param sample_args: pandas resample方法其他参数
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    unit = 'T'



class OHLCSampler(base.OrderingTransformer):
    """生成OHLC数据

    :param rule: 抽样规则，见pandas resample方法的文档
    :param sample_args: pandas resample方法其他参数
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    def __init__(self, rule: str = '1S', sample_ars=None, ordering:Optional[Literal['asc', 'dsc']] = 'asc'):
        self.rule = rule
        self.sample_args = sample_ars or {}
        self.ordering = ordering
        self._data = None

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        _cust_transform = Resampler(self.rule,
                                    method='ohlc',
                                    sample_args=self.sample_args,
                                    ordering=None).fit(X)
        return _cust_transform.transform(X)

    
class OHLCVSampler(base.OrderingTransformer):
    """生成OHLCV数据

    :param rule: 抽样规则，见pandas resample方法的文档
    :param sample_args: pandas resample方法其他参数
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    def __init__(self, rule: str = '1S', price_col: str = 'last_price', vol_col: str = 'qty', sample_ars=None, ordering:Optional[Literal['asc', 'dsc']] = 'asc'):
        self.rule = rule
        self.price_col = price_col
        self.vol_col = 'qty'
        self.sample_args = sample_ars or {}
        self.ordering = ordering
        self._data = None

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        _cust_transform = Resampler(self.rule,
                                    method='ohlc',
                                    sample_args=self.sample_args,
                                    ordering=None).fit(data[self.price_col])
        ohlc = _cust_transform.transform(data[self.price_col])
        _vol_trans = Resampler(self.rule,
                                    method='sum',
                                    sample_args=self.sample_args,
                                    ordering=None).fit(data[self.vol_col])
        vol = _vol_trans.transform(data[self.vol_col])
        return pd.concat([ohlc, vol], axis=1)