"""技术分析指标"""

from typing import Union, Sequence, Any, Callable, Optional
from typing_extensions import Literal
import numpy as np  # type: ignore
import pandas as pd  # type: ignore
from numba import jit
from sklearn.base import BaseEstimator, TransformerMixin
from . import utils, base


ArrayLike = Union[np.ndarray, pd.Series, Sequence[Any]]


def _mva_func(func: Callable[..., pd.Series],
              s: ArrayLike,
              ordered: Literal['desc', 'asc', None] = None,
              drop_na: bool = False) -> pd.Series:
    s = pd.Series(s)

    if ordered == 'asc':
        s = s.sort_index(ascending=True)
    if ordered == 'desc':
        s = s.sort_index(ascending=False)

    res = func(s)

    if drop_na:
        res = res.dropna()

    return res


def ma(s: ArrayLike,
       n: int,
       ordered: Literal['desc', 'asc', None] = None,
       drop_na: bool = False) -> pd.Series:
    """计算移动平均

    Args:
        s (ArrayLike): 时间序列
        n (int): 窗口长度
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
        drop_na (bool): 是否drop空值
    """

    return _mva_func(lambda x: x.rolling(n).mean(), s, ordered, drop_na)


class MA(base.TimeCheckTransformer):
    """计算移动平均

    Args:
        col: 指定计算列
        n (int): 窗口长度
        prefix: 生成列前缀
    """
    ma: Optional[pd.Series] = None

    def __init__(self, col: str,  n: int = 5, prefix: str = 'ma', ordering: Optional[Literal['asc', 'dsc']] = None):
        self.col = col
        self.n = n
        self.prefix = prefix
        self.ordering = ordering

    def _cust_fit(self, X: pd.DataFrame, y=None):
        data = X
        col_name = "_".join([f"{self.prefix}", self.col])
        data[col_name] = ma(data[self.col], self.n)
        self._data = data
        self.ma = self._data[col_name]

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data.copy()


def ema(s: ArrayLike,
        n: int,
        ordered: Literal['desc', 'asc', None] = None,
        drop_na: bool = False) -> pd.Series:
    """计算指数平滑移动平均

    Args:
        s (ArrayLike): 时间序列
        n (int): 窗口长度
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
        drop_na (bool): 是否drop空值
    """
    return _mva_func(lambda x: x.ewm(span=n, adjust=False).mean(),
                     s, ordered, drop_na)


class EMA(BaseEstimator, TransformerMixin):
    """计算指数平滑移动平均

        Args:
            col: 指定计算列
            n (int): 窗口长度
            prefix: 生成列前缀
        """

    def __init__(self, col: str, n: int = 5, prefix: str = 'ema'):
        self.col = col
        self.n = n
        self.prefix = prefix

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        col_name = "_".join([f"{self.prefix}", self.col])
        data[col_name] = ema(data[self.col], self.n)
        return data


def macd(s: ArrayLike,
         n: int = 9,
         fast: int = 12,
         slow: int = 26,
         ordered: Literal['desc', 'asc', None] = None,
         suffix: str = '') -> pd.DataFrame:
    """计算MACD

    Args:
        s (ArrayLike): 时间序列
        n (int): 窗口长度
        fast (int): 快线窗口长度
        slow (int): 慢线窗口长度
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
        drop_na (bool): 是否drop空值
    """
    s = pd.Series(s)
    if ordered == 'asc':
        s = s.sort_index(ascending=True)
    if ordered == 'desc':
        s = s.sort_index(ascending=False)

    dif = ema(s, fast) - ema(s, slow)  # 快线
    dea = ema(dif, n)  # 慢线
    bar = 2 * (dif - dea)  # 柱子
    cols = [utils.make_col_name(col, suffix=suffix) for col in ['dif', 'dea', 'macd']]
    return pd.DataFrame(np.c_[dif, dea, bar], columns=cols, index=s.index)


class MACD(BaseEstimator, TransformerMixin):
    """计算MACD

    Args:
        col: 指定计算列
        n (int): 窗口长度
        fast (int): 快线窗口长度
        slow (int): 慢线窗口长度
    """
    def __init__(self, col: str,  n: int = 9, fast: int = 12, slow: int = 26):
        self.col = col
        self.n = n
        self.fast = fast
        self.slow = slow

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        _macd = macd(data[self.col], n=self.n, fast=self.fast, slow=self.slow, suffix=self.col)
        res = pd.concat([data, _macd], axis=1)
        return res


def cci_a(df: pd.DataFrame,
          n: int = 9,
          ordered: Literal['desc', 'asc', None] = None) -> pd.Series:
    """计算cci

        Args:
            s (ArrayLike): 时间序列
            n (int): 窗口长度
            ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
    """
    dfn = df.copy()
    if ordered == 'asc':
        dfn = dfn.sort_index(ascending=True)
    if ordered == 'desc':
        dfn = dfn.sort_index(ascending=False)

    tp = (dfn.high + dfn.low + dfn.close) / 3  # TP=（最高价+最低价+收盘价）÷3
    ma_ = ma(dfn.close, n)  # MA=近N日收盘价的均值
    md = ma((ma_ - dfn.close).abs(), n)  # MD=近N日（MA－收盘价）的绝对值的均值
    cci = (tp - ma_) / md / 0.015  # CCI=（TP－MA）÷MD÷0.015
    return cci


class CCI_A(BaseEstimator, TransformerMixin):
    """计算cci
    
    只适用于，OHLC数据

    Args:
        col:
        n (int): 窗口长度
    """
    def __init__(self, col: str, n: int = 9):
        self.col = col
        self.n = n

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        col_name = utils.make_col_name(self.col, prefix='cci')
        data[col_name] = cci_a(data[self.col], n=self.n)
        return data


def cci_b(df: pd.DataFrame,
          n: int = 9,
          ordered: Optional[Literal['desc', 'asc']] = None) -> pd.Series:
    """计算cci
    
    只适用于，OHLC数据

    Args:
        s (ArrayLike): 时间序列
        n (int): 窗口长度
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
    """
    dfn = df.copy()
    if ordered == 'asc':
        dfn = dfn.sort_index(ascending=True)
    if ordered == 'desc':
        dfn = dfn.sort_index(ascending=False)

    tp = (dfn.high + dfn.low + dfn.close) / 3  # TP=（最高价+最低价+收盘价）÷3
    ma_ = ma(tp, n)  # MA=近N日收盘价的均值
    mabs = ma((ma_ - dfn.close).abs(), n)  # MABS=近N日的abs（TP－MA）的均值
    cci = (tp - ma_) / mabs / 0.015  # CCI=（TP－MA）÷MD÷0.015
    return cci


class CCI_B(BaseEstimator, TransformerMixin):
    """计算cci
    
    只适用于，OHLC数据

    Args:
        n (int): 窗口长度
    """

    def __init__(self, col: str, n: int = 9):
        self.col = col
        self.n = n

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        col_name = utils.make_col_name(self.col, prefix='cci')
        data[col_name] = cci_b(data[self.col], n=self.n)
        return data


def bollin(s: ArrayLike,
           n: int = 12,
           m: int = 2,
           columns: Sequence[str] = ('upper', 'middle', 'lower'),
           prefix: str = '',
           suffix: str = '',
           ordered: Literal['desc', 'asc', None] = None) -> pd.DataFrame:
    """计算布林通道

    Args:
        s (ArrayLike): 时间序列
        n (int): 移动平均长度
        m (int): 通道宽度
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
    """
    s = pd.Series(s)
    if ordered == 'asc':
        s = s.sort_index(ascending=True)
    if ordered == 'desc':
        s = s.sort_index(ascending=False)

    mid = ma(s, n)  # 中轨
    std = s.rolling(n).std()  # 标准差
    up = mid + m * std  # 上轨
    down = mid - m * std  # 下轨
    return pd.DataFrame(np.c_[up, mid, down],
                        index=s.index,
                        columns=utils.make_cols_name(columns, prefix=prefix, suffix=suffix))


class Bollin(BaseEstimator, TransformerMixin):
    """计算布林通道

    Args:
        n (int): 移动平均长度
        m (int): 通道宽度
    """

    def __init__(self, col: str,  n: int = 9, m: int = 2):
        self.col = col
        self.n = n
        self.m = m

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        _bollin = bollin(data[self.col], n=self.n, m=self.m, suffix=self.col)
        return pd.concat([data, _bollin], axis=1)


@jit(nopython=True)  # type: ignore
def _calc_kd(rsv):
    """辅助计算kd指标函数

    单独抽离出来用numba加速

    Args:
        rsv (np.ndarray): rsv数组

    Returns:
        (tuple): 返回k、d两个指标
    """
    k = np.zeros_like(rsv)
    d = np.zeros_like(rsv)

    # 若无前一日K值与D值则用50来代替
    k[0] = 50.  # type: ignore
    d[0] = 50.  # type: ignore

    for i, r in enumerate(rsv[1:], 1):
        # 当日K = 2/3 * 前一日K值 + 1/3 * 当日RSV
        last_k = k[-1]
        k[i] = 2 / 3 * last_k + 1 / 3 * r  # type: ignore

        # 当日D = 2/3 * 前一日D值 + 1/3 * 当日K
        last_d = d[-1]
        d[i] = 2 / 3 * last_d + 1 / 3 * k[i]  # type: ignore

    return k, d


def kdj(df: pd.DataFrame,
        n: int = 9,
        columns=('k', 'd', 'j'),
        prefix: str = '',
        suffix: str = '',
        ordered: Literal['desc', 'asc', None] = None) -> pd.DataFrame:
    """计算kdj
    
    只适用于OHLC数据

    Args:
        s (ArrayLike): 时间序列
        n (int): 窗口长度
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
    """
    dfn = df.copy()
    if ordered == 'asc':
        dfn = dfn.sort_index(ascending=True)
    if ordered == 'desc':
        dfn = dfn.sort_index(ascending=False)

    # n日内最低价
    min_low_n = df['low'].rolling(n).min().fillna(value=df['low'].expanding().min())
    # n日内最高价
    max_high_n = df['high'].rolling(n).max().fillna(value=df['high'].expanding().max())

    rsv = (df['close'] - min_low_n) / (max_high_n - min_low_n) * 100.  # 收盘价归一化

    k, d = _calc_kd(rsv.values)
    # 当日J = 3 * 当日K值 – 2 * 当日D值
    j = 3 * k - 2 * d  # type: ignore
    return pd.DataFrame(np.c_[k, d, j],
                        index=dfn.index,
                        columns=utils.make_cols_name(columns, prefix=prefix, suffix=suffix))


class KDJ(BaseEstimator, TransformerMixin):
    """计算kdj
    
    只适用于OHLC数据

    Args:
        n (int): 窗口长度
    """

    def __init__(self, col: str, n: int = 9):
        self.col = col
        self.n = n

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        _kdj = kdj(data[self.col], n=self.n, suffix=self.col)
        return pd.concat([data, _kdj], axis=1)


@jit(nopython=True)  # type: ignore
def _rsi(s):
    """辅助计算rsi指标函数

    单独抽离出来用numba加速

    Args:
        s (np.ndarray): 变化幅度的时间序列

    Returns:
        (np.ndarray): rsi指标
    """
    a = np.sum(s[s > 0])  # 涨幅合计
    b = np.sum(np.abs(s[s <= 0]))  # 跌幅合计
    if a + b == 0:
        return 0
    return a / (a + b) * 100  # 跌幅占比


def rsi(s: ArrayLike,
        n: int = 9,
        ordered: Literal['desc', 'asc', None] = None) -> pd.Series:
    """计算rsi

    Args:
        s (ArrayLike): 时间序列
        n (int): 窗口长度
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
    """
    s = pd.Series(s)
    if ordered == 'asc':
        s = s.sort_index(ascending=True)
    if ordered == 'desc':
        s = s.sort_index(ascending=False)

    chg = s.diff()  # 涨跌幅
    chg.index = s.index

    return chg.rolling(n).agg(lambda x: _rsi(x.values))


class RSI(BaseEstimator, TransformerMixin):
    """计算RSI

    Args:
        n (int): 窗口长度
    """

    def __init__(self, col: str,  n: int = 9):
        self.col = col
        self.n = n

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        col_name = utils.make_col_name(self.col, prefix='rsi')
        data[col_name] = rsi(data[self.col], n=self.n)
        return data


def emv(df: pd.DataFrame,
        n: int = 9,
        m: int = 9,
        columns=('emv', 'maemv'),
        prefix: str = '',
        suffix: str = '',
        ordered: Literal['desc', 'asc', None] = None) -> pd.DataFrame:
    """计算emv

    必须是ohlcv数据 open, high, low, close, volume

    Args:
        s (ArrayLike): 时间序列
        n (int): 窗口长度
        m (int):
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
    """
    dfn = df.copy()
    if ordered == 'asc':
        dfn = dfn.sort_index(ascending=True)
    if ordered == 'desc':
        dfn = dfn.sort_index(ascending=False)

    a = (df['high'] + df['low']) / 2  # A =（今日最高价+今日最低价）/ 2
    b = a.shift(1)  # B =（前日最高价+前日最低价）/ 2
    c = (df['high'] - df['low'])  # C = 今日最高价 – 今日最低价
    em = (a - b) * c / df['volume']  # EM =（A – B）* C / 今日成交量
    emv = em.rolling(n).sum()  # EMV(n) = n日内EM的加总
    maemv = emv.rolling(m).mean()  # MAEMV(m) = m日EMV的移动平均

    return pd.DataFrame(np.c_[emv, maemv],
                        index=dfn.index,
                        columns=utils.make_cols_name(columns, prefix=prefix, suffix=suffix))


class EMV(BaseEstimator, TransformerMixin):
    """简易波动

    必须是ohlcv数据 open, high, low, close, volume

    Args:
        n (int): 窗口长度
        m (int):
    """

    def __init__(self, n: int = 9, m: int = 9):
        self.n = n
        self.m = m

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        _emv = emv(data, n=self.n, m=self.m)
        return pd.concat([data, _emv], axis=1)


def obv(s: ArrayLike,
        ordered: Literal['desc', 'asc', None] = None) -> pd.Series:
    """计算obv

    Args:
        s (ArrayLike): 时间序列
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
    """
    s = pd.Series(s)
    if ordered == 'asc':
        s = s.sort_index(ascending=True)
    if ordered == 'desc':
        s = s.sort_index(ascending=False)

    # 当日值 = 带符号的当日成交量
    obv = s.copy()
    sign = obv.copy()
    sign[obv.pct_change() > 0] = 1
    sign[obv.pct_change() == 0] = 0
    sign[obv.pct_change() < 0] = -1
    sign[0] = 1
    return (obv * sign).cumsum()  # 当日OBV = 当日值 + 前一日OBV


class OBV(BaseEstimator, TransformerMixin):
    """计算obv

        """
    def __init__(self, col: str):
        self.col = col

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        col_name = utils.make_col_name(self.col, prefix='obv')
        data[col_name] = obv(data[self.col])
        return data


def bias(s: ArrayLike,
         n: int,
         ordered: Literal['desc', 'asc', None] = None) -> pd.Series:
    """计算bias

    Args:
        s (ArrayLike): 时间序列
        n (int): 窗口长度
        ordered (Literal['desc', 'asc', None]): 排序方式，None表示不排序
    """
    s = pd.Series(s)
    if ordered == 'asc':
        s = s.sort_index(ascending=True)
    if ordered == 'desc':
        s = s.sort_index(ascending=False)

    ma_ = ma(s, n)
    bias = (s - ma_) / ma_ * 100  # BIAS(n) =（收盘价 – 收盘价n日移动平均）/ 收盘价n日移动平均 * 100
    return bias


class BIAS(BaseEstimator, TransformerMixin):
    """计算bias

    Args:
        n (int): 窗口长度

        """

    def __init__(self, col: str,  n: int = 9):
        self.col = col
        self.n = n

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        data = X.sort_index()
        col_name = utils.make_col_name(self.col, prefix='bias')
        data[col_name] = bias(data[self.col], n=self.n)
        return data