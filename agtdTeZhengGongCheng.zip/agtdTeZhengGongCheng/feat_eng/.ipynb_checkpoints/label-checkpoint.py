"""labeling模块"""
from . import stats


# 统计未来特征
FutureStats = stats.FutureStats

# 统计过去特征
PastStats = stats.PastStats
