"""统计特征"""
from typing_extensions import Literal
from typing import Optional, Callable

import pandas as pd

from . import base



class MvStd(base.TimeCheckTransformer):
    """计算指定列的移动标准差

    :param col: 指定列
    :param n: 窗口长度
    :param prefix: 新增列名后缀
    """
    mvstd: Optional[pd.Series] = None

    def __init__(self, col: str, n: int = 5, prefix: str = 'mvstd'):
        self.col = col
        self.n = n
        self.prefix = prefix

    def _cust_fit(self, X: pd.DataFrame, y=None):
        data = X
        col_name = "_".join([f"{self.prefix}", self.col])
        data[col_name] = data[self.col].rolling(self.n).std()
        self._data = data
        self.mvstd = self._data[col_name]

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return self._data.copy()


# 生成年月日时分秒
def add_ymd_hms(self, data: pd.DataFrame):
    """生成年月日时分秒"""
    return data.assign(
        year=lambda x: x.index.year,
        month=lambda x: x.index.month,
        day=lambda x: x.index.day,
        hour=lambda x: x.index.hour,
        minute=lambda x: x.index.minute,
        second=lambda x: x.index.second
    )

class YMD_HMS(base.TimeCheckTransformer):
    """生成年月日时分秒特征列
    """

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        return X.assign(
            year=lambda x: x.index.year,
            month=lambda x: x.index.month,
            day=lambda x: x.index.day,
            hour=lambda x: x.index.hour,
            minute=lambda x: x.index.minute,
            second=lambda x: x.index.second
        )


class FutureStats(base.TimeCheckTransformer):
    """生成未来一段时间统计特征列，不含当前时刻

    :param col: 指定列
    :param n: 窗口长度
    :param method: 统计方法
    :param func: 自定义统计函数
    :param unit: 时间单位，用于生成列名后缀
    :param include: 是否包含当前时刻
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    def __init__(self,
                 col: str,
                 n: int = 5,
                 method: Literal['max', 'min', 'mean', 'std'] = 'max',
                 func: Optional[Callable] = None,
                 unit: str = '',
                 include: bool = False,
                 ordering: Optional[Literal['asc', 'dsc']] = None):
        self.col = col
        self.n = n
        self.method = method
        self.func = func
        self.unit = unit
        self.include = include
        self.ordering = ordering

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        col_name = "_".join(filter(lambda x: len(x) > 0, [self.col, self.method, 'within', str(self.n), self.unit]))
        n = self.n - 1 if self.include else self.n
        p = self.n if not self.unit else str(self.n) + self.unit
        data[col_name] = data[self.col].rolling(p).agg(self.func or self.method).shift(-n)
        return data


class PastStats(base.TimeCheckTransformer):
    """生成过去一段时间统计特征列，不含当前时刻

    :param col: 指定列
    :param n: 窗口长度
    :param method: 统计方法
    :param func: 自定义统计函数
    :param unit: 时间单位，用于生成列名后缀
    :param include: 是否包含当前时刻
    :param ordering: None -> 不按时间索引排序; asc -> 按时间索引升序排序; dsc -> 按时间索引降序排序;
    """

    def __init__(self,
                 col: str,
                 n: int = 5,
                 method: Literal['max', 'min', 'mean', 'std'] = 'max',
                 func: Optional[Callable] = None,
                 unit: str = '',
                 include: bool = False,
                 ordering: Optional[Literal['asc', 'dsc']] = None):
        self.col = col
        self.n = n
        self.unit = ''
        self.method = method
        self.func = func
        self.unit = unit
        self.include = include
        self.ordering = ordering

    def _cust_transform(self, X: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        data = X.copy()
        col_name = "_".join(filter(lambda x: len(x) > 0, [self.col, self.method, 'past', str(self.n), self.unit]))
        n = 0 if self.include else 1
        p = self.n if not self.unit else str(self.n) + self.unit
        data[col_name] = data[self.col].rolling(p).agg(self.func or self.method).shift(n)
        return data