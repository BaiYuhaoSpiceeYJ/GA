"""辅助工具"""
from typing import Sequence, List, TypeVar


T = TypeVar('T')
U = TypeVar('U')


def make_col_name(col: str, *, sep: str = '_', prefix: str = '', suffix: str = '') -> str:
    ls = [prefix, col, suffix]
    return sep.join(filter(lambda x: len(x) > 0, ls))

def make_cols_name(cols: Sequence[str], *, sep: str = '_', prefix: str = '', suffix: str = '') -> List[str]:
    return [
        make_col_name(col, prefix=prefix, suffix=suffix)
        for col in cols
    ]


def concat_str(*args: str, sep: str = '_') -> str:
    return sep.join(filter(lambda x: len(x) > 0, args))


def assign(x, v):
    x = v
    return