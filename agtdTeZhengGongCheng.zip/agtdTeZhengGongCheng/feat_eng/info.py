"""信息理论模型"""
from . import base
import pandas as pd
import numpy as np


def get_bin_cap(vol: pd.Series, n: int = 50):
    return vol.sum() / len(vol) * n


def get_vpin_simple(data: pd.DataFrame, 
                    price_col: str = 'close', 
                    vol_col: str = 'qty', 
                    time_col: str = 'tx_time',
                    open_col: str = 'open', 
                    high_col: str = 'high',
                    low_col: str = 'low',
                    close_col: str = 'close',
                    drop_vol_na: bool = False,
                    drop_temp: bool = False,
                    cap_coef: int = 50):
    if not drop_vol_na:
        df = data.copy()
    else:
        df = data.copy().dropna(subset=[vol_col])
    df['diff'] = df[price_col].diff()
    df['inc'] = df['diff'] > 0
    df['dec'] = df['diff'] <= 0
    df['pct'] = df[price_col] / df[price_col].shift(1) - 1
    df['vol_buy'] = df[vol_col] * df['inc']
    df['vol_buy_w'] = df['vol_buy'] * df['pct']
    df['vol_sell'] = df[vol_col] * df['dec']
    df['vol_sell_w'] = df['vol_sell'] * df['pct']

    bin_cap = get_bin_cap(df[vol_col], cap_coef)
    df['bin'] = np.floor(df[vol_col].cumsum() / bin_cap).astype('int')

    grouped = df.groupby('bin')
    vol_bin = grouped[vol_col].sum()
    vol_buy = grouped['vol_buy'].sum()
    vol_sell = grouped['vol_sell'].sum()
    vol_buy_w = grouped['vol_buy_w'].sum()
    vol_sell_w = grouped['vol_sell_w'].sum()
    bin_bars = grouped[vol_col].agg(lambda x: len(x))
    vol_rel = vol_buy_w + vol_sell_w
    vpin_signed = (vol_buy - vol_sell) / vol_bin / bin_bars
    vpin = (vol_buy - vol_sell).abs() / vol_bin / bin_bars
    vol_time = grouped[time_col].last()

    mkt_df = grouped.agg({
        open_col: 'first',
        high_col: 'max',
        low_col: 'min',
        close_col: 'last'
    })
    res = pd.concat([vol_time, mkt_df, vol_bin, vol_buy, vol_sell, vol_buy_w, vol_sell_w, vol_rel, vpin, vpin_signed], axis=1, ignore_index=True)
    res.columns = [time_col, open_col, high_col, low_col, close_col, 'vol_bin', 'vol_buy', 'vol_sell', 'vol_buy_w', 'vol_sell_w', 'vol_rel', 'vpin', 'vpin_signed']
    if drop_temp:
        res = res.drop(columns=['vol_bin', 'vol_buy', 'vol_sell', 'vol_buy_w', 'vol_sell_w', 'vol_rel', 'vpin_signed'])
    # res = res.rename(columns={0: 'vol_rel', 1: 'vpin', 2: 'vpin_signed'}).reset_index()
    return res.reset_index()



class SimpleVpin(base.BaseTransformer, base.SupportSelector):
    """简单版VPIN
    
    按照给定容量，计算vpin，如果没有给定容量，则根据分通系数（cap_coef）计算
    :param bin_cap: 每个桶的容量
    :param cap_coef: 桶容量系数，当bin_cap<=0时，使用`get_bin_cap`函数计算
    :param price_col: 价格列列名
    :param vol_col: 交易量列名
    :param tx_time: 时间列列名
    :param open_col: 开盘价列名
    :param high_col: 最高价列名
    :param low_col: 最低价列名
    :param close_col: 收盘价列名
    :param drop_vol_na: 是否丢弃交易量是空或者为0的行
    :param drop_temp: 是否丢弃中间计算变量，如果True仅保留VPIN的计算结果
    """

    def __init__(self,
                 bin_cap: float = 0.,
                 cap_coef: int = 50,
                 price_col: str = 'close',
                 vol_col: str = 'qty',
                 time_col: str = 'tx_time',
                 open_col: str = 'open',
                 high_col: str = 'high',
                 low_col: str = 'low',
                 close_col: str = 'close',
                 drop_vol_na: bool = False,
                 drop_temp: bool = False, ):
        self.price_col = price_col
        self.vol_col = vol_col
        self.time_col = time_col
        self.open_col = open_col
        self.high_col = high_col
        self.low_col = low_col
        self.close_col = close_col
        self.drop_vol_na = drop_vol_na
        self.drop_temp = drop_temp
        self.bin_cap = bin_cap
        self.cap_coef = cap_coef

    def fit(self, X=None, y=None):
        df = X.copy()
        # 如果self.bin_cap没有给定，就根据cap_coef计算桶的容量
        if self.bin_cap <= 0.:
            self.bin_cap = get_bin_cap(df[self.vol_col], self.cap_coef)
        return self

    def transform(self, X: pd.DataFrame, *args, **kwargs):

        from pandas.api.types import is_datetime64_dtype

        if not is_datetime64_dtype(X[self.time_col]):
            raise ValueError(f"{self.time_col} is not datetime type. Convert it into datetime first!")

        if not self.drop_vol_na:
            df = X.copy()
        else:
            df = X.dropna(subset=[self.vol_col])
            df = df.query(f'{self.vol_col} > 0')
        df['diff'] = df[self.price_col].diff()
        df['inc'] = df['diff'] > 0
        df['dec'] = df['diff'] <= 0
        df['pct'] = df[self.price_col] / df[self.price_col].shift(1) - 1
        df['vol_buy'] = df[self.vol_col] * df['inc']
        df['vol_buy_w'] = df['vol_buy'] * df['pct']
        df['vol_sell'] = df[self.vol_col] * df['dec']
        df['vol_sell_w'] = df['vol_sell'] * df['pct']        
        df['bin'] = np.floor(df[self.vol_col].cumsum() / self.bin_cap).astype('int')

        grouped = df.groupby('bin')
        vol_bin = grouped[self.vol_col].sum()
        vol_buy = grouped['vol_buy'].sum()
        vol_sell = grouped['vol_sell'].sum()
        vol_buy_w = grouped['vol_buy_w'].sum()
        vol_sell_w = grouped['vol_sell_w'].sum()
        bin_bars = grouped[self.vol_col].agg(lambda x: len(x))
        vol_rel = vol_buy_w + vol_sell_w
        vpin_signed = (vol_buy - vol_sell) / vol_bin / bin_bars
        vpin = (vol_buy - vol_sell).abs() / vol_bin / bin_bars
        vol_time = grouped[self.time_col].last()

        mkt_df = grouped.agg({
            self.open_col: 'first',
            self.high_col: 'max',
            self.low_col: 'min',
            self.close_col: 'last'
        })
        res = pd.concat([vol_time, mkt_df, vol_bin, vol_buy, vol_sell, vol_buy_w, vol_sell_w, vol_rel, vpin, vpin_signed], axis=1, ignore_index=True)
        res.columns = [self.time_col, self.open_col, self.high_col, self.low_col, self.close_col, 'vol_bin', 'vol_buy', 'vol_sell', 'vol_buy_w', 'vol_sell_w', 'vol_rel', 'vpin', 'vpin_signed']
        res = res.reset_index()
        if self.drop_temp:
            res = res.drop(columns=['bin', 'vol_bin', 'vol_buy', 'vol_sell', 'vol_buy_w', 'vol_sell_w', 'vol_rel', 'vpin_signed'])
            self.new_cols = ['vpin']
        else:
            self.new_cols = ['bin', 'vol_bin', 'vol_buy', 'vol_sell', 'vol_buy_w', 'vol_sell_w', 'vol_rel', 'vpin', 'vpin_signed']
        return res



class Vpin(base.BaseTransformer, base.SupportSelector):
    """plus版VPIN
    
    按照给定容量，计算vpin，如果没有给定容量，则根据分通系数（cap_coef）计算

    :param bin_cum: 每天的分桶数量，当bin_cap<=0时，将每天的交易量分成bin_cum个桶
    :param bin_cap: 每个桶的容量
    :param price_col: 价格列列名
    :param vol_col: 交易量列名
    :param tx_time: 时间列列名
    :param open_col: 开盘价列名
    :param high_col: 最高价列名
    :param low_col: 最低价列名
    :param close_col: 收盘价列名
    :param drop_vol_na: 是否丢弃交易量是空或者为0的行
    :param drop_temp: 是否丢弃中间计算变量，如果True仅保留VPIN的计算结果
    """

    def __init__(self,
                 bin_cap: float = 0.,
                 bin_num: int = 50,
                 price_col: str = 'close',
                 vol_col: str = 'qty',
                 time_col: str = 'tx_time',
                 open_col: str = 'open',
                 high_col: str = 'high',
                 low_col: str = 'low',
                 close_col: str = 'close',
                 drop_vol_na: bool = False,
                 drop_temp: bool = False, ):
        self.price_col = price_col
        self.vol_col = vol_col
        self.time_col = time_col
        self.open_col = open_col
        self.high_col = high_col
        self.low_col = low_col
        self.close_col = close_col
        self.drop_vol_na = drop_vol_na
        self.drop_temp = drop_temp
        self.bin_cap = bin_cap
        self.bin_num = bin_num

    def fit(self, X=None, y=None):
        return self

    def transform(self, X: pd.DataFrame, *args, **kwargs):

        from pandas.api.types import is_datetime64_dtype

        if not is_datetime64_dtype(X[self.time_col]):
            raise ValueError(f"{self.time_col} is not datetime type. Convert it into datetime first!")

        if not self.drop_vol_na:
            df = X.copy()
        else:
            df = X.dropna(subset=[self.vol_col])
            df = df.query(f'{self.vol_col} > 0')

        df['diff'] = df[self.price_col].diff()
        df['inc'] = df['diff'] > 0
        df['dec'] = df['diff'] <= 0
        df['pct'] = df[self.price_col] / df[self.price_col].shift(1) - 1
        df['vol_buy'] = df[self.vol_col] * df['inc']
        df['vol_buy_w'] = df['vol_buy'] * df['pct']
        df['vol_sell'] = df[self.vol_col] * df['dec']
        df['vol_sell_w'] = df['vol_sell'] * df['pct']        

        # 如果没有指定bin_cap，就将每天的交易量分成bin_num个桶
        series_dt = df[self.time_col]
        yme = df.groupby([series_dt.dt.year, series_dt.dt.month, series_dt.dt.day])
        if self.bin_cap <= 0.:            
            df['bin'] = np.ceil(yme[self.vol_col].transform('cumsum') / (yme[self.vol_col].transform('sum') / self.bin_num))
        else:
            df['bin'] = np.ceil(yme[self.vol_col].transform('cumsum') / self.bin_cap)

        df['bin'] = df['bin'].astype('int')

        grouped = df.groupby([series_dt.dt.year, series_dt.dt.month, series_dt.dt.day, df['bin']])
        vol_bin = grouped[self.vol_col].sum()
        vol_buy = grouped['vol_buy'].sum()
        vol_sell = grouped['vol_sell'].sum()
        vol_buy_w = grouped['vol_buy_w'].sum()
        vol_sell_w = grouped['vol_sell_w'].sum()
        bin_bars = grouped[self.vol_col].agg(lambda x: len(x))
        vol_rel = vol_buy_w + vol_sell_w
        vpin_signed = (vol_buy - vol_sell) / vol_bin / bin_bars
        vpin = (vol_buy - vol_sell).abs() / vol_bin / bin_bars
        vol_time = grouped[self.time_col].last()

        mkt_df = grouped.agg({
            self.open_col: 'first',
            self.high_col: 'max',
            self.low_col: 'min',
            self.close_col: 'last'
        })

        res = pd.concat([vol_time, mkt_df, vol_bin, vol_buy, vol_sell, vol_buy_w, vol_sell_w, vol_rel, vpin, vpin_signed], axis=1, ignore_index=True)
        res.columns = [self.time_col, self.open_col, self.high_col, self.low_col, self.close_col, 'vol_bin', 'vol_buy', 'vol_sell', 'vol_buy_w', 'vol_sell_w', 'vol_rel', 'vpin', 'vpin_signed']
        res = res.reset_index(level='bin')
        res = res.reset_index(drop=True)
        if self.drop_temp:
            res = res.drop(columns=['bin', 'vol_bin', 'vol_buy', 'vol_sell', 'vol_buy_w', 'vol_sell_w', 'vol_rel', 'vpin_signed'])
            self.new_cols = ['vpin']
        else:
            self.new_cols = ['bin', 'vol_bin', 'vol_buy', 'vol_sell', 'vol_buy_w', 'vol_sell_w', 'vol_rel', 'vpin', 'vpin_signed']
        return res